package defence;

import aic2020.user.*;

public class Fumigator extends MyUnitClass {

    Fumigator(UnitController uc) {
        super(uc);
    }


    void play() {
moveRandomly();    }

}
